module.exports = {

     //'url' : 'mongodb://username:password@hostname:post/database' 
	 'url' : 'mongodb://127.0.0.1:27017/test' 
     //Please replace your host file Here : 127.1.1.0 , Express is Collection Name (Database Name)
};